/*const {Builder, By, Key, until} = require('selenium-webdriver');
let driver = new Builder().forBrowser('chrome').build();
driver.get("http://192.168.11.186/Migracion-Web/admin/login");

console.log("aaa");
//driver.findElement(By.xpath('/html/body/div[2]/div[1]')).click();
//driver.wait(until.titleIs('JS30: 01 Drums'), 1000);
driver.close();
*/

require('chromedriver');
var webdriver = require('selenium-webdriver');
var driver = new webdriver.Builder()
  .forBrowser('chrome')
  .build();
  
console.log("prueba 1");


const URL='http://192.168.11.186/Migracion-Web/admin/login'; 


driver.get( URL ); 


console.log("prueba 2");



// For Chrome
capabilities = DesiredCapabilities::chrome();
capabilities->setCapability( 'acceptSslCerts', true );


$driver = RemoteWebDriver::create( $host, $capabilities, 5000 );
$driver->get( 'https://store.localhost/' )




/*
ChromeOptions options = new ChromeOptions();
Map<String, Object> prefs = new HashMap<String, Object>();
prefs.put("profile.default_content_settings.popups", 0);
options.setExperimentalOption("prefs", prefs);




const {Builder, By, Key, until} = require('selenium-webdriver');

DesiredCapabilities handlSSLErr = DesiredCapabilities.chrome ()       
handlSSLErr.setCapability (CapabilityType.ACCEPT_SSL_CERTS, true)
//WebDriver driver = new ChromeDriver (handlSSLErr);


var driver = new webdriver.Builder()
    .forBrowser('chromium')
    .setFirefoxOptions( )
    .setChromeOptions( )
    .build();
*/




/*const {Builder, By, Key, until} = require('selenium-webdriver');

var webdriver = require('selenium-webdriver')
var chrome = require('selenium-webdriver/chrome'),
//var firefox = require('selenium-webdriver/firefox');
 
var driver = new webdriver.Builder()
    .forBrowser('chromium')
    .setFirefoxOptions( )
    .setChromeOptions( )
    .build();
    
    */
    


/*var webdriverio = require('webdriverio');

var options = {
    desiredCapabilities: {
        browserName: 'chrome'
    }
};

webdriverio
  .remote(options)
  .init()
  .url('www.google.cl')
  .saveScreenshot('buddyworks.png') 
  .end();


element = await driver.findElement(By.id("login")); 


*/


/*var webdriverio = require('webdriverio'),
client = webdriverio.remote({
	desiredCapabilities: {
		browserName: 'firefox', version: '45', platform: 'WINDOWS', name: 'This is an example test'
	},
	host: 'hub.testingbot.com',
	port: 80,
	user: 'api_key',
	key: 'api_secret'
}).init();


console.log("paso111");


client
	.url('https://google.com')
	.setValue('*[name="q"]','webdriverio')
	.click('*[name="btnG"]').pause(1000)
	.getTitle(function(err,title) {
		console.log(title);
	}).end();
	
	
	
console.log("paso222");*/
	

/*const  webdriver from 'selenium-webdriver'
import chrome from 'selenium-webdriver/chrome'
import chromedriver from 'chromedriver'
const TIMEOUT = 300000000

export default async () => {
 chrome.setDefaultService( new chrome.ServiceBuilder( 
chromedriver.path ).build() )

 const chromeCapabilities = webdriver.Capabilities.chrome()

 const chromeOptions = { 'args': [ 'user-data-dir=/Users/user/selenium/bp/' ] }
chromeCapabilities.set( 'chromeOptions', chromeOptions )

 const driver = new webdriver.Builder()
.withCapabilities( chromeCapabilities )
.build()

 await driver.manage().setTimeouts( { implicit: TIMEOUT, pageLoad: 
TIMEOUT, script: TIMEOUT } )
console.info( await driver.manage().getTimeouts() )

 return driver
}
*/
/*

//Run using this project (https://github.com/qmu/dockerfiles/blob/master/src/selenium-webdriver-node/example/bin/run)

"use strict";

const webdriver = require('selenium-webdriver'),
    By = webdriver.By,
    until = webdriver.until,
    test = require('selenium-webdriver/testing');

   
//const expect = require('expect.js');
const assert = require('assert');


var driver = new webdriver.Builder()
   .withCapabilities({'browserName': 'chrome','name':'Chrome Test','tz':'America/Los_Angeles','build':'Chrome Build','idleTimeout':'60'})
   .usingServer('http://localhost:4444/wd/hub')
   .build();



console.log('starting chrome...');

//driver.manage().timeouts().implicitlyWait(10 * 1000);//10 seconds


driver.get('http://somewebsite.tech');
driver.findElement(webdriver.By.name('_username')).sendKeys('**');
driver.findElement(webdriver.By.name('_password')).sendKeys('**');
driver.findElement(webdriver.By.css("button")).click();
driver.quit();


console.log('all modules are ready!');
*/
